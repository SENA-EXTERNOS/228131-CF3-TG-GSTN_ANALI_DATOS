function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6DHBDxTM3KL":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

